class GameClass {

    #title
    #releaseDate
    #platform

    constructor(title, releaseDate, platform) {
        this.#title = title;
        this.#releaseDate = releaseDate;
        this.#platform = platform;
    }

    get title() {
        return this.#title;
    }
    get releaseDate() {
        return this.#releaseDate;
    }

    get platform() {
        return this.#platform;
    }

    set title(newTitle) {
        this.#title = newTitle;
    }

    set releaseDate(newReleaseDate) {
        this.#releaseDate = newReleaseDate;
    }

    set platform(newpPlatform) {
        this.#platform = newpPlatform;
    }

}