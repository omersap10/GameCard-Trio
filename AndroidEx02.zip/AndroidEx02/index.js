document.getElementById('goButton').addEventListener('click', async () => {
    try {
        const response = await fetch('http://localhost:3000/games');

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();

        const titles = data.map(game => game.title).join('\n');
        const releaseDates = data.map(game => game.releaseDate).join('\n');
        const platforms = data.map(game => game.platform).join('\n');

        const arrTitles = titles.split("\n");
        const arrReleaseDates = releaseDates.split("\n");
        const arrPlatforms = platforms.split("\n");

        const arrGames = []

        for (let i = 0; i < arrTitles.length; i++) {
            arrGames.push(new GameClass(arrTitles[i], arrReleaseDates[i], arrPlatforms[i]));
        }
        arrGames.forEach(url => {
            const cardContainer = document.createElement('div');
            cardContainer.classList.add('card');
            cardContainer.style.margin = "10p%";

            const h3Title = document.createElement('h3');
            h3Title.innerText = url.title;

            const h3ReleaseDate = document.createElement('h3');
            h3ReleaseDate.innerText = url.releaseDate;

            const h3Platform = document.createElement('h3');
            h3Platform.innerText = url.platform;

            cardContainer.appendChild(h3Title);
            cardContainer.appendChild(h3ReleaseDate);
            cardContainer.appendChild(h3Platform);

            document.getElementById('svgcontainer').appendChild(cardContainer);
        })
    } catch (error) {
        console.error('Fetch error:', error);
    }
});
