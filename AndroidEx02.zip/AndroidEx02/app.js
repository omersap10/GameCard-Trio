const express = require('express');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(cors());
app.get('/games', async (req, res) => {
    try {
        const apiResponse = await fetch('https://www.freetogame.com/api/games');

        if (!apiResponse.ok) {
            throw new Error(`HTTP error! Status: ${apiResponse.status}`);
        }

        const data = await apiResponse.json();

        const formattedData = data.map(game => ({
            title: game.title,
            releaseDate: game.release_date,
            platform: game.platform
        }));

        res.json(formattedData);
    } catch (error) {
        console.error('Fetch error:', error);
        res.status(500).send('Internal Server Error');
    }
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
